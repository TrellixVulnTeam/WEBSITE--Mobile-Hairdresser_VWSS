AOS.init({
    offsel: 200,
    duration: 800
  });